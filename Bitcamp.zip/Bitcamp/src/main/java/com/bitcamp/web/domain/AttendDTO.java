package com.bitcamp.web.domain;

import lombok.Data;

@Data
public class AttendDTO {
	private String id, week, status;

	
}
