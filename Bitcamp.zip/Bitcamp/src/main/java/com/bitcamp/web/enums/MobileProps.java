package com.bitcamp.web.enums;

public enum MobileProps {
	CUSTOMER_NUM, PHONE_NUM,REGDATE,USERID
}
