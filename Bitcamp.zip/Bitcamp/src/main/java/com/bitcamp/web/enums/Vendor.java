package com.bitcamp.web.enums;

public enum Vendor {
	ORACLE, MYSQL, MARIADB
}
