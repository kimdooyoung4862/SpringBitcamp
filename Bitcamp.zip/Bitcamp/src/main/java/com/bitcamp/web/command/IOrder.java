package com.bitcamp.web.command;

public interface IOrder {
	public void execute();
}
