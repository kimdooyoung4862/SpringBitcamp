package com.bitcamp.web.domain;

import lombok.Data;

@Data
public class FoodDTO {
	private String menu, price, count, foodSeq;
}
