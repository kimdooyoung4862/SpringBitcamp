package com.bitcamp.web.enums;

public enum Table {
	MEMBER, ATTEND, ACCOUNT,MOBILE
	
}
