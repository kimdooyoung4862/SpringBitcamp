package com.bitcamp.web.enums;

public enum DML {
	INSERT, INTO,SELECT,WHERE,AND,FROM,VALUES,
	DELETE
	
}







