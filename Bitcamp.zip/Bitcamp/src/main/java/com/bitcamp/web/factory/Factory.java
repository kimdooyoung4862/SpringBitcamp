package com.bitcamp.web.factory;

public abstract class Factory {
	public abstract Object create();
}
