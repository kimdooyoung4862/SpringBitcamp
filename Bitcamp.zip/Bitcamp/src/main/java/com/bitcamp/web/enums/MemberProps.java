package com.bitcamp.web.enums;

public enum MemberProps {
	ID, PASS, NAME, SSN, 
		PHONE, EMAIL, ADDR, PROFILE
}
