package com.bitcamp.web.domain;

import lombok.Data;

@Data
public class MobileDTO {
	private String customerNum,phoneNum,regdate,id;
}
